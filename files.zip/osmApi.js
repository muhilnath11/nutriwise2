// src/utils/osmApi.js
// Queries OpenStreetMap Overpass API for nearby restaurants/food places

/**
 * Haversine formula — distance between two lat/lon points in km
 */
const haversineDistance = (lat1, lon1, lat2, lon2) => {
  const R = 6371 // Earth radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180
  const dLon = ((lon2 - lon1) * Math.PI) / 180
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) *
    Math.cos((lat2 * Math.PI) / 180) *
    Math.sin(dLon / 2) ** 2
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
}

/**
 * Format distance as human-readable string
 */
const formatDistance = (km) => {
  if (km < 1) return `${Math.round(km * 1000)}m`
  return `${km.toFixed(1)}km`
}

/**
 * Tags that suggest a diet-friendly restaurant
 * (vegetarian, healthy, South/North Indian)
 */
const DIET_FRIENDLY_CUISINE = [
  'indian', 'vegetarian', 'vegan', 'south_indian', 'north_indian',
  'regional', 'thali', 'healthy', 'salad', 'juice'
]

/**
 * Check if an OSM element is likely diet-compatible
 */
const isDietFriendly = (tags = {}, diseases = []) => {
  const cuisine = (tags.cuisine || '').toLowerCase()
  const name    = (tags.name    || '').toLowerCase()

  const hasFriendlyCuisine = DIET_FRIENDLY_CUISINE.some(
    (c) => cuisine.includes(c) || name.includes(c)
  )

  // Extra: if user has diseases, flag fast-food heavy places as "partial" only
  const isFastFood = ['mcdonald', 'kfc', 'pizza', 'burger', 'fried'].some(
    (f) => name.includes(f)
  )

  if (isFastFood && diseases.length > 0 && !diseases.includes('none')) return 'no'
  if (hasFriendlyCuisine) return 'match'
  return 'partial'
}

/**
 * Fetch nearby food places from Overpass API
 *
 * @param {number} lat
 * @param {number} lon
 * @param {string[]} diseases - active disease constraints
 * @param {number} radiusMeters - search radius (default 2000m)
 * @returns {Promise<object[]>}
 */
export const fetchNearbyFood = async (lat, lon, diseases = [], radiusMeters = 2000) => {
  // Overpass QL query: restaurants, cafes, fast_food, food courts near point
  const query = `
    [out:json][timeout:15];
    (
      node["amenity"~"restaurant|cafe|fast_food|food_court"]["name"](around:${radiusMeters},${lat},${lon});
      way["amenity"~"restaurant|cafe|fast_food|food_court"]["name"](around:${radiusMeters},${lat},${lon});
    );
    out center 30;
  `

  const url = `https://overpass-api.de/api/interpreter?data=${encodeURIComponent(query)}`

  const res = await fetch(url)
  if (!res.ok) throw new Error('Failed to fetch nearby restaurants')

  const data = await res.json()

  // Parse + enrich elements
  const places = (data.elements || [])
    .filter((el) => el.tags?.name)
    .map((el) => {
      const elLat = el.lat || el.center?.lat
      const elLon = el.lon || el.center?.lon
      const dist = haversineDistance(lat, lon, elLat, elLon)

      return {
        id: el.id,
        name: el.tags.name,
        type: el.tags.amenity || 'restaurant',
        cuisine: el.tags.cuisine || '',
        address: el.tags['addr:street'] || el.tags['addr:full'] || '',
        phone: el.tags.phone || el.tags['contact:phone'] || '',
        openingHours: el.tags.opening_hours || '',
        distance: dist,
        distanceFormatted: formatDistance(dist),
        dietMatch: isDietFriendly(el.tags, diseases),
        lat: elLat,
        lon: elLon,
      }
    })
    .filter((p) => p.dietMatch !== 'no') // Remove clearly incompatible places
    .sort((a, b) => a.distance - b.distance) // Nearest first
    .slice(0, 15) // Cap at 15 results

  return places
}
