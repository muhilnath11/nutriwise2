// src/components/layout/Navbar.jsx

import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import { useUI } from '../../context/UIContext'
import ModeToggle from '../ui/ModeToggle'

const Navbar = () => {
  const { user, logout } = useAuth()
  const { isElder } = useUI()
  const navigate = useNavigate()

  const handleLogout = () => {
    logout()
    navigate('/auth')
  }

  return (
    <nav className="navbar">
      <Link to="/" className="navbar-brand">
        🥗 Diet<span>Wise</span>
      </Link>

      <div className="flex gap-sm" style={{ alignItems: 'center' }}>
        <ModeToggle />
        {user && (
          <button
            className="btn btn-ghost"
            onClick={handleLogout}
            style={{ fontSize: 'var(--fs-xs)', padding: '8px 12px' }}
          >
            {isElder ? '🚪 Logout' : 'Logout'}
          </button>
        )}
      </div>
    </nav>
  )
}

export default Navbar
