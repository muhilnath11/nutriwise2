// src/context/UIContext.jsx
// Manages elder/standard UI mode — persists to localStorage + syncs body class

import { createContext, useContext, useState, useEffect, useCallback } from 'react'

const UIContext = createContext(null)

export const UIProvider = ({ children }) => {
  const [uiMode, setUiMode] = useState(() => {
    return localStorage.getItem('uiMode') || 'standard'
  })

  // Sync body class for global CSS targeting
  useEffect(() => {
    if (uiMode === 'elder') {
      document.body.classList.add('elder-mode')
    } else {
      document.body.classList.remove('elder-mode')
    }
  }, [uiMode])

  const toggleMode = useCallback((mode) => {
    const newMode = mode || (uiMode === 'elder' ? 'standard' : 'elder')
    localStorage.setItem('uiMode', newMode)
    setUiMode(newMode)
  }, [uiMode])

  const isElder = uiMode === 'elder'

  return (
    <UIContext.Provider value={{ uiMode, isElder, toggleMode }}>
      {children}
    </UIContext.Provider>
  )
}

export const useUI = () => {
  const ctx = useContext(UIContext)
  if (!ctx) throw new Error('useUI must be used within UIProvider')
  return ctx
}
