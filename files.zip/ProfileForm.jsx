// src/components/profile/ProfileForm.jsx
// Complete health profile form with voice input support

import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import api from '../../api/axios'
import { useAuth } from '../../context/AuthContext'
import { useUI } from '../../context/UIContext'
import useVoiceInput from '../../hooks/useVoiceInput'

const DISEASES = [
  { key: 'diabetes',       label: '🩸 Diabetes' },
  { key: 'hypertension',   label: '💓 Hypertension' },
  { key: 'heart_disease',  label: '❤️ Heart Disease' },
  { key: 'kidney_disease', label: '🫘 Kidney Disease' },
  { key: 'arthritis',      label: '🦴 Arthritis' },
  { key: 'none',           label: '✅ None' },
]

const ACTIVITY_LEVELS = [
  { key: 'sedentary',   label: 'Sedentary',    desc: 'Desk job, little exercise' },
  { key: 'light',       label: 'Light',         desc: '1–3 days exercise/week' },
  { key: 'moderate',    label: 'Moderate',      desc: '3–5 days exercise/week' },
  { key: 'active',      label: 'Active',        desc: '6–7 days exercise/week' },
  { key: 'very_active', label: 'Very Active',   desc: 'Physical job + exercise' },
]

const GOALS = [
  { key: 'loss',     label: '📉 Lose Weight',    desc: 'Calorie deficit plan' },
  { key: 'maintain', label: '⚖️ Maintain',        desc: 'Stay at current weight' },
  { key: 'gain',     label: '📈 Gain Muscle',     desc: 'Calorie surplus plan' },
]

const FOOD_PREFS = [
  { key: 'vegetarian',     label: '🥦 Vegetarian' },
  { key: 'non-vegetarian', label: '🍗 Non-Vegetarian' },
  { key: 'vegan',          label: '🌱 Vegan' },
]

// Parses voice transcript → tries to fill a field
const parseVoiceToField = (transcript, fieldName) => {
  const t = transcript.toLowerCase().trim()
  if (fieldName === 'age') {
    const num = t.match(/\d+/)
    return num ? num[0] : transcript
  }
  if (fieldName === 'weight') {
    const num = t.match(/\d+(\.\d+)?/)
    return num ? num[0] : transcript
  }
  if (fieldName === 'height') {
    const num = t.match(/\d+(\.\d+)?/)
    return num ? num[0] : transcript
  }
  return transcript
}

const ProfileForm = () => {
  const { user, updateUser } = useAuth()
  const { isElder } = useUI()
  const navigate = useNavigate()

  const [form, setForm] = useState({
    age: '',
    gender: '',
    height: '',
    weight: '',
    activityLevel: 'sedentary',
    goal: 'maintain',
    diseases: ['none'],
    foodPreference: 'vegetarian',
    allergies: '',
    uiMode: 'standard',
  })

  const [activeVoiceField, setActiveVoiceField] = useState(null)
  const [errors, setErrors] = useState({})
  const [saving, setSaving] = useState(false)
  const [saveMsg, setSaveMsg] = useState('')

  // Load existing profile
  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const { data } = await api.get('/profile')
        if (data.success) {
          const p = data.profile
          setForm({
            age: p.age || '',
            gender: p.gender || '',
            height: p.height || '',
            weight: p.weight || '',
            activityLevel: p.activityLevel || 'sedentary',
            goal: p.goal || 'maintain',
            diseases: p.diseases?.length ? p.diseases : ['none'],
            foodPreference: p.foodPreference || 'vegetarian',
            allergies: p.allergies?.join(', ') || '',
            uiMode: p.uiMode || 'standard',
          })
        }
      } catch {
        // New user — use defaults
      }
    }
    fetchProfile()
  }, [])

  // Voice input handler — fills the currently active voice field
  const handleVoiceResult = (transcript) => {
    if (!activeVoiceField) return
    const parsed = parseVoiceToField(transcript, activeVoiceField)
    setForm((p) => ({ ...p, [activeVoiceField]: parsed }))
    setActiveVoiceField(null)
  }

  const { listening, error: voiceError, supported: voiceSupported, toggleListening } = useVoiceInput(handleVoiceResult)

  const startVoiceFor = (field) => {
    setActiveVoiceField(field)
    toggleListening()
  }

  const handleChange = (e) => {
    const { name, value } = e.target
    setForm((p) => ({ ...p, [name]: value }))
    setErrors((p) => ({ ...p, [name]: '' }))
  }

  const toggleDisease = (key) => {
    setForm((p) => {
      let next = [...p.diseases]
      if (key === 'none') return { ...p, diseases: ['none'] }
      // Remove 'none' if real disease selected
      next = next.filter((d) => d !== 'none')
      if (next.includes(key)) {
        next = next.filter((d) => d !== key)
        if (next.length === 0) next = ['none']
      } else {
        next.push(key)
      }
      return { ...p, diseases: next }
    })
  }

  const validate = () => {
    const errs = {}
    if (!form.age || isNaN(form.age) || form.age < 1 || form.age > 120) errs.age = 'Enter a valid age (1–120)'
    if (!form.gender) errs.gender = 'Please select gender'
    if (!form.height || isNaN(form.height) || form.height < 50 || form.height > 300) errs.height = 'Enter height in cm (50–300)'
    if (!form.weight || isNaN(form.weight) || form.weight < 10 || form.weight > 500) errs.weight = 'Enter weight in kg (10–500)'
    setErrors(errs)
    return Object.keys(errs).length === 0
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!validate()) return
    setSaving(true)
    setSaveMsg('')
    try {
      const payload = {
        age: Number(form.age),
        gender: form.gender,
        height: Number(form.height),
        weight: Number(form.weight),
        activityLevel: form.activityLevel,
        goal: form.goal,
        diseases: form.diseases,
        foodPreference: form.foodPreference,
        allergies: form.allergies
          ? form.allergies.split(',').map((a) => a.trim()).filter(Boolean)
          : [],
        uiMode: isElder ? 'elder' : form.uiMode,
      }
      const { data } = await api.put('/profile', payload)
      if (data.success) {
        updateUser({ profileComplete: true })
        setSaveMsg('✅ Profile saved! Generating your plan...')
        setTimeout(() => navigate('/plan'), 1200)
      }
    } catch (err) {
      setSaveMsg(err.response?.data?.message || '❌ Failed to save profile. Please try again.')
    } finally {
      setSaving(false)
    }
  }

  // Voice button inline — small mic icon next to numeric fields
  const VoiceFieldBtn = ({ field }) => {
    if (!voiceSupported) return null
    const isActive = listening && activeVoiceField === field
    return (
      <button
        type="button"
        onClick={() => startVoiceFor(field)}
        style={{
          position: 'absolute', right: '12px', top: '50%', transform: 'translateY(-50%)',
          background: isActive ? 'var(--danger)' : 'var(--secondary)',
          border: 'none', borderRadius: '50%', width: '32px', height: '32px',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          cursor: 'pointer', fontSize: '0.9rem',
          animation: isActive ? 'pulse 1s infinite' : 'none',
        }}
        title={`Say your ${field} aloud`}
      >
        🎤
      </button>
    )
  }

  return (
    <div className="app-shell fade-in">
      <div style={{
        background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-light) 100%)',
        padding: 'var(--gap-lg)',
        color: 'white',
      }}>
        <div style={{ fontSize: 'var(--fs-xs)', opacity: 0.8, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.08em' }}>
          Health Profile
        </div>
        <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: 'var(--fs-xl)', fontWeight: 700, marginTop: '4px' }}>
          Tell us about yourself
        </h2>
        <p style={{ fontSize: 'var(--fs-sm)', opacity: 0.85, marginTop: '4px' }}>
          This helps us build your personalised nutrition plan
        </p>
        {voiceSupported && (
          <div style={{ marginTop: 'var(--gap-sm)', fontSize: 'var(--fs-xs)', opacity: 0.75 }}>
            🎤 Tap the mic icons to fill fields with your voice
          </div>
        )}
      </div>

      <form onSubmit={handleSubmit} className="page-content" noValidate>

        {/* ── Basic Info ─────────────────────────────────────────── */}
        <div className="card mb-md">
          <div className="section-title">📋 Basic Information</div>

          {/* Age */}
          <div className="form-group">
            <label className="form-label">Age (years)</label>
            <div style={{ position: 'relative' }}>
              <input
                type="number" name="age" min="1" max="120"
                className={`form-input ${errors.age ? 'error' : ''}`}
                placeholder={isElder ? 'e.g. 65' : 'Your age'}
                value={form.age} onChange={handleChange}
                style={{ paddingRight: voiceSupported ? '50px' : '16px' }}
              />
              <VoiceFieldBtn field="age" />
            </div>
            {errors.age && <span className="form-error">{errors.age}</span>}
          </div>

          {/* Gender */}
          <div className="form-group">
            <label className="form-label">Gender</label>
            <div className="chip-group">
              {['male', 'female', 'other'].map((g) => (
                <div
                  key={g}
                  className={`chip ${form.gender === g ? 'active' : ''}`}
                  onClick={() => { setForm((p) => ({ ...p, gender: g })); setErrors((p) => ({ ...p, gender: '' })) }}
                >
                  {g === 'male' ? '♂ Male' : g === 'female' ? '♀ Female' : '⚧ Other'}
                </div>
              ))}
            </div>
            {errors.gender && <span className="form-error">{errors.gender}</span>}
          </div>

          {/* Height */}
          <div className="form-group">
            <label className="form-label">Height (cm)</label>
            <div style={{ position: 'relative' }}>
              <input
                type="number" name="height" min="50" max="300"
                className={`form-input ${errors.height ? 'error' : ''}`}
                placeholder={isElder ? 'e.g. 165' : 'Height in centimetres'}
                value={form.height} onChange={handleChange}
                style={{ paddingRight: voiceSupported ? '50px' : '16px' }}
              />
              <VoiceFieldBtn field="height" />
            </div>
            {errors.height && <span className="form-error">{errors.height}</span>}
          </div>

          {/* Weight */}
          <div className="form-group">
            <label className="form-label">Weight (kg)</label>
            <div style={{ position: 'relative' }}>
              <input
                type="number" name="weight" min="10" max="500"
                className={`form-input ${errors.weight ? 'error' : ''}`}
                placeholder={isElder ? 'e.g. 70' : 'Weight in kilograms'}
                value={form.weight} onChange={handleChange}
                style={{ paddingRight: voiceSupported ? '50px' : '16px' }}
              />
              <VoiceFieldBtn field="weight" />
            </div>
            {errors.weight && <span className="form-error">{errors.weight}</span>}
          </div>
        </div>

        {/* ── Activity & Goal ────────────────────────────────────── */}
        <div className="card mb-md">
          <div className="section-title">🏃 Activity & Goal</div>

          <div className="form-group">
            <label className="form-label">Activity Level</label>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--gap-sm)' }}>
              {ACTIVITY_LEVELS.map((a) => (
                <div
                  key={a.key}
                  onClick={() => setForm((p) => ({ ...p, activityLevel: a.key }))}
                  style={{
                    padding: 'var(--gap-sm) var(--gap-md)',
                    borderRadius: 'var(--radius-md)',
                    border: `2px solid ${form.activityLevel === a.key ? 'var(--primary)' : 'var(--border)'}`,
                    background: form.activityLevel === a.key ? 'var(--secondary)' : 'var(--off-white)',
                    cursor: 'pointer',
                    transition: 'all var(--t-normal)',
                  }}
                >
                  <div style={{ fontWeight: 700, color: form.activityLevel === a.key ? 'var(--primary-dark)' : 'var(--text-primary)', fontSize: 'var(--fs-base)' }}>
                    {a.label}
                  </div>
                  <div style={{ fontSize: 'var(--fs-xs)', color: 'var(--text-muted)' }}>{a.desc}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">Your Goal</label>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--gap-sm)' }}>
              {GOALS.map((g) => (
                <div
                  key={g.key}
                  onClick={() => setForm((p) => ({ ...p, goal: g.key }))}
                  style={{
                    padding: 'var(--gap-sm) var(--gap-md)',
                    borderRadius: 'var(--radius-md)',
                    border: `2px solid ${form.goal === g.key ? 'var(--primary)' : 'var(--border)'}`,
                    background: form.goal === g.key ? 'var(--secondary)' : 'var(--off-white)',
                    cursor: 'pointer',
                    transition: 'all var(--t-normal)',
                  }}
                >
                  <div style={{ fontWeight: 700, color: form.goal === g.key ? 'var(--primary-dark)' : 'var(--text-primary)', fontSize: 'var(--fs-base)' }}>
                    {g.label}
                  </div>
                  <div style={{ fontSize: 'var(--fs-xs)', color: 'var(--text-muted)' }}>{g.desc}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* ── Medical & Diet ─────────────────────────────────────── */}
        <div className="card mb-md">
          <div className="section-title">🏥 Medical & Diet</div>

          <div className="form-group">
            <label className="form-label">Health Conditions (select all that apply)</label>
            <div className="chip-group">
              {DISEASES.map((d) => (
                <div
                  key={d.key}
                  className={`chip ${form.diseases.includes(d.key) ? 'active' : ''}`}
                  onClick={() => toggleDisease(d.key)}
                >
                  {d.label}
                </div>
              ))}
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">Food Preference</label>
            <div className="chip-group">
              {FOOD_PREFS.map((fp) => (
                <div
                  key={fp.key}
                  className={`chip ${form.foodPreference === fp.key ? 'active' : ''}`}
                  onClick={() => setForm((p) => ({ ...p, foodPreference: fp.key }))}
                >
                  {fp.label}
                </div>
              ))}
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">Allergies (optional)</label>
            <input
              type="text" name="allergies"
              className="form-input"
              placeholder="e.g. nuts, gluten, dairy (comma separated)"
              value={form.allergies} onChange={handleChange}
            />
            <span style={{ fontSize: 'var(--fs-xs)', color: 'var(--text-muted)', marginTop: '4px' }}>
              Separate multiple allergies with commas
            </span>
          </div>
        </div>

        {/* Voice error */}
        {voiceError && (
          <div className="alert alert-warning mb-md">
            <span>🎤</span> {voiceError}
          </div>
        )}

        {/* Save message */}
        {saveMsg && (
          <div className={`alert ${saveMsg.startsWith('✅') ? 'alert-success' : 'alert-danger'} mb-md`}>
            {saveMsg}
          </div>
        )}

        <button
          type="submit"
          className={`btn btn-primary btn-block ${isElder ? 'btn-lg' : ''}`}
          disabled={saving}
        >
          {saving ? '⏳ Saving...' : '✅ Save & Generate My Plan'}
        </button>

        <div style={{ height: 'var(--gap-xl)' }} />
      </form>
    </div>
  )
}

export default ProfileForm
