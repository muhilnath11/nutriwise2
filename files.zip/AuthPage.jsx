// src/components/auth/AuthPage.jsx
// Login + Signup toggled on one screen

import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import { useUI } from '../../context/UIContext'

const AuthPage = () => {
  const [mode, setMode] = useState('login') // 'login' | 'signup'
  const [form, setForm] = useState({ name: '', email: '', password: '' })
  const [fieldErrors, setFieldErrors] = useState({})
  const { login, signup, loading, error, clearError, isAuthenticated } = useAuth()
  const { isElder } = useUI()
  const navigate = useNavigate()

  // If already logged in, redirect to profile
  useEffect(() => {
    if (isAuthenticated) navigate('/')
  }, [isAuthenticated, navigate])

  const handleChange = (e) => {
    setForm((p) => ({ ...p, [e.target.name]: e.target.value }))
    setFieldErrors((p) => ({ ...p, [e.target.name]: '' }))
    clearError()
  }

  // Client-side validation
  const validate = () => {
    const errs = {}
    if (mode === 'signup' && !form.name.trim()) errs.name = 'Name is required'
    if (!form.email.trim() || !/\S+@\S+\.\S+/.test(form.email)) errs.email = 'Valid email is required'
    if (!form.password || form.password.length < 6) errs.password = 'Password must be at least 6 characters'
    setFieldErrors(errs)
    return Object.keys(errs).length === 0
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!validate()) return

    let result
    if (mode === 'login') {
      result = await login(form.email, form.password)
    } else {
      result = await signup(form.name, form.email, form.password)
    }

    if (result?.success) {
      navigate('/profile')
    }
  }

  const switchMode = () => {
    setMode((m) => (m === 'login' ? 'signup' : 'login'))
    setFieldErrors({})
    clearError()
  }

  return (
    <div className="app-shell fade-in">
      {/* Hero section */}
      <div className="auth-hero">
        <span className="auth-hero-emoji">🥗</span>
        <h1>DietWise</h1>
        <p>Your smart nutrition advisor — personalised for your health</p>
      </div>

      {/* Form section */}
      <div className="auth-form-wrap" style={{ marginTop: '-20px' }}>
        {/* Tab switcher */}
        <div className="mode-toggle mb-lg" style={{ maxWidth: '240px', margin: '0 auto var(--gap-lg)' }}>
          <button className={mode === 'login' ? 'active' : ''} onClick={() => setMode('login')}>
            Log In
          </button>
          <button className={mode === 'signup' ? 'active' : ''} onClick={() => setMode('signup')}>
            Sign Up
          </button>
        </div>

        <form onSubmit={handleSubmit} noValidate>
          {/* Name — signup only */}
          {mode === 'signup' && (
            <div className="form-group">
              <label className="form-label">Your Name</label>
              <input
                type="text"
                name="name"
                className={`form-input ${fieldErrors.name ? 'error' : ''}`}
                placeholder="e.g. Ravi Kumar"
                value={form.name}
                onChange={handleChange}
                autoComplete="name"
              />
              {fieldErrors.name && <span className="form-error">{fieldErrors.name}</span>}
            </div>
          )}

          {/* Email */}
          <div className="form-group">
            <label className="form-label">Email Address</label>
            <input
              type="email"
              name="email"
              className={`form-input ${fieldErrors.email ? 'error' : ''}`}
              placeholder="you@example.com"
              value={form.email}
              onChange={handleChange}
              autoComplete="email"
            />
            {fieldErrors.email && <span className="form-error">{fieldErrors.email}</span>}
          </div>

          {/* Password */}
          <div className="form-group">
            <label className="form-label">Password</label>
            <input
              type="password"
              name="password"
              className={`form-input ${fieldErrors.password ? 'error' : ''}`}
              placeholder="Minimum 6 characters"
              value={form.password}
              onChange={handleChange}
              autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
            />
            {fieldErrors.password && <span className="form-error">{fieldErrors.password}</span>}
          </div>

          {/* API error */}
          {error && (
            <div className="alert alert-danger mb-md">
              <span>⚠️</span> {error}
            </div>
          )}

          {/* Submit */}
          <button
            type="submit"
            className={`btn btn-primary btn-block ${isElder ? 'btn-lg' : ''}`}
            disabled={loading}
            style={{ marginTop: 'var(--gap-md)' }}
          >
            {loading ? '⏳ Please wait...' : mode === 'login' ? '🚀 Log In' : '✅ Create Account'}
          </button>
        </form>

        <div className="divider">or</div>

        <button className="btn btn-outline btn-block" onClick={switchMode}>
          {mode === 'login' ? "Don't have an account? Sign Up" : 'Already have an account? Log In'}
        </button>

        {isElder && (
          <div className="alert alert-info mt-lg">
            <span>ℹ️</span>
            <span>Need help? Ask a family member or caregiver to help you create an account.</span>
          </div>
        )}
      </div>
    </div>
  )
}

export default AuthPage
