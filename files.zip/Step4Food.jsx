// src/components/steps/Step4Food.jsx
// Step 4: Nearby diet-compatible restaurants via OpenStreetMap Overpass API

import { useState } from 'react'
import { useUI } from '../../context/UIContext'
import useLocation from '../../hooks/useLocation'
import { fetchNearbyFood } from '../../utils/osmApi'
import Disclaimer from '../ui/Disclaimer'

const DIET_MATCH_CONFIG = {
  match:   { label: '✓ Matches Diet', bg: '#d4f8e8', color: '#1a7a4a' },
  partial: { label: '~ Partial Match', bg: '#fff3cd', color: '#856404' },
}

const FoodCard = ({ place, index }) => {
  const { isElder } = useUI()
  const matchCfg = DIET_MATCH_CONFIG[place.dietMatch] || DIET_MATCH_CONFIG.partial

  return (
    <div
      className="food-card fade-in"
      style={{ animationDelay: `${index * 0.06}s` }}
    >
      <div className="food-card-left" style={{ flex: 1 }}>
        <h4 style={{ fontSize: isElder ? 'var(--fs-md)' : 'var(--fs-base)' }}>{place.name}</h4>
        <p>
          {place.type && (
            <span style={{ textTransform: 'capitalize', marginRight: '6px' }}>
              {place.type.replace('_', ' ')}
            </span>
          )}
          {place.cuisine && (
            <span style={{ color: 'var(--primary)', fontWeight: 600 }}>· {place.cuisine}</span>
          )}
        </p>
        <div style={{ display: 'flex', gap: '8px', marginTop: '4px', flexWrap: 'wrap' }}>
          <span style={{ fontSize: 'var(--fs-xs)', color: 'var(--text-muted)' }}>
            📍 {place.distanceFormatted} away
          </span>
          {place.openingHours && (
            <span style={{ fontSize: 'var(--fs-xs)', color: 'var(--text-muted)' }}>
              🕐 {place.openingHours}
            </span>
          )}
        </div>
      </div>
      <div>
        <span
          className="food-card-badge"
          style={{ background: matchCfg.bg, color: matchCfg.color }}
        >
          {matchCfg.label}
        </span>
      </div>
    </div>
  )
}

const Step4Food = ({ planData }) => {
  const { isElder } = useUI()
  const { coords, city, setCity, locationError, locating, getGPSLocation, geocodeCity } = useLocation()

  const [places, setPlaces] = useState([])
  const [searching, setSearching] = useState(false)
  const [searchError, setSearchError] = useState(null)
  const [searched, setSearched] = useState(false)
  const [manualCity, setManualCity] = useState('')

  const diseases = planData?.activeConstraints || []

  const doSearch = async (lat, lon) => {
    setSearching(true)
    setSearchError(null)
    try {
      const results = await fetchNearbyFood(lat, lon, diseases, 2000)
      setPlaces(results)
      setSearched(true)
      if (results.length === 0) {
        setSearchError('No diet-compatible restaurants found within 2km. Try a wider area.')
      }
    } catch {
      setSearchError('Could not reach the map service. Please check your internet and try again.')
    } finally {
      setSearching(false)
    }
  }

  const handleGPS = async () => {
    getGPSLocation()
  }

  // When coords arrive from GPS hook, trigger search
  const handleSearchWithCoords = async () => {
    if (!coords) return
    doSearch(coords.lat, coords.lon)
  }

  const handleManualSearch = async () => {
    if (!manualCity.trim()) return
    await geocodeCity(manualCity)
  }

  // Watch coords after geocode resolves
  const handleGeocodedSearch = async () => {
    if (coords) {
      doSearch(coords.lat, coords.lon)
    }
  }

  const matchCount = places.filter((p) => p.dietMatch === 'match').length

  return (
    <div className="fade-in">
      <div className="page-title">🗺 Nearby Food</div>
      <div className="page-subtitle">
        Find restaurants near you that match your dietary needs
      </div>

      {/* Location section */}
      <div className="card mb-md mt-md">
        <div className="section-title">📍 Your Location</div>

        {/* GPS button */}
        <button
          className={`btn btn-primary btn-block ${isElder ? 'btn-lg' : ''}`}
          onClick={async () => { handleGPS(); setTimeout(handleSearchWithCoords, 2500) }}
          disabled={locating || searching}
          style={{ marginBottom: 'var(--gap-md)' }}
        >
          {locating ? '📡 Getting Location...' : '📡 Use My Current Location'}
        </button>

        <div className="divider">or enter manually</div>

        {/* Manual city input */}
        <div style={{ display: 'flex', gap: 'var(--gap-sm)' }}>
          <input
            type="text"
            className="form-input"
            placeholder={isElder ? 'Type your city name' : 'e.g. Chennai, Anna Nagar'}
            value={manualCity}
            onChange={(e) => setManualCity(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleManualSearch()}
            style={{ flex: 1 }}
          />
          <button
            className="btn btn-secondary"
            onClick={async () => {
              await handleManualSearch()
              setTimeout(handleGeocodedSearch, 1500)
            }}
            disabled={locating || searching || !manualCity.trim()}
          >
            Search
          </button>
        </div>

        {/* Coords confirmed */}
        {coords && !searching && (
          <div className="alert alert-success mt-md">
            <span>✅</span>
            <span>
              Location found ({coords.lat.toFixed(3)}, {coords.lon.toFixed(3)}).
              {!searched && (
                <button
                  style={{ marginLeft: '8px', fontWeight: 700, color: 'var(--primary)', background: 'none', border: 'none', cursor: 'pointer', textDecoration: 'underline' }}
                  onClick={() => doSearch(coords.lat, coords.lon)}
                >
                  Search now →
                </button>
              )}
            </span>
          </div>
        )}

        {/* Location error */}
        {locationError && (
          <div className="alert alert-warning mt-md">
            <span>⚠️</span> {locationError}
          </div>
        )}
      </div>

      {/* Searching spinner */}
      {searching && (
        <div className="spinner-wrap">
          <div className="spinner" />
          <div style={{ color: 'var(--primary)', fontWeight: 700 }}>Searching nearby restaurants...</div>
          <div style={{ fontSize: 'var(--fs-xs)', color: 'var(--text-muted)' }}>
            Using OpenStreetMap data
          </div>
        </div>
      )}

      {/* Search error */}
      {searchError && !searching && (
        <div className="alert alert-warning mb-md">
          <span>⚠️</span> {searchError}
        </div>
      )}

      {/* Results */}
      {searched && !searching && places.length > 0 && (
        <>
          <div className="section-title">
            🍽 Results ({places.length} found · {matchCount} match your diet)
          </div>

          {/* Diet match legend */}
          <div style={{ display: 'flex', gap: 'var(--gap-sm)', marginBottom: 'var(--gap-md)', flexWrap: 'wrap' }}>
            <span className="food-card-badge match">✓ Matches Diet</span>
            <span className="food-card-badge partial">~ Partial Match</span>
          </div>

          {/* Sort: matches first */}
          {[...places]
            .sort((a, b) => (a.dietMatch === 'match' ? -1 : 1))
            .map((place, i) => (
              <FoodCard key={place.id} place={place} index={i} />
            ))
          }

          <div className="alert alert-info mt-md">
            <span>💡</span>
            <span style={{ fontSize: 'var(--fs-xs)' }}>
              Always confirm with the restaurant that they can accommodate your dietary restrictions.
              {diseases.includes('hypertension') && ' Request low-salt preparation.'}
              {diseases.includes('diabetes') && ' Ask about sugar content in sauces.'}
            </span>
          </div>
        </>
      )}

      {/* No results placeholder */}
      {!searched && !searching && (
        <div className="card" style={{ textAlign: 'center', padding: 'var(--gap-2xl) var(--gap-lg)' }}>
          <div style={{ fontSize: '3rem', marginBottom: 'var(--gap-md)' }}>🗺</div>
          <div style={{ fontWeight: 700, fontSize: 'var(--fs-md)', color: 'var(--text-primary)', marginBottom: 'var(--gap-sm)' }}>
            Find Nearby Restaurants
          </div>
          <div style={{ fontSize: 'var(--fs-sm)', color: 'var(--text-muted)' }}>
            Allow location access or enter your city to discover diet-compatible restaurants near you
          </div>
        </div>
      )}

      <Disclaimer />
      <div style={{ height: 'var(--gap-xl)' }} />
    </div>
  )
}

export default Step4Food
