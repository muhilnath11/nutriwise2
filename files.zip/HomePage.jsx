// src/pages/HomePage.jsx
// Landing page — authenticated users see dashboard, guests see welcome

import { Link } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { useUI } from '../context/UIContext'
import Navbar from '../components/layout/Navbar'

const HomePage = () => {
  const { user, isAuthenticated } = useAuth()
  const { isElder } = useUI()

  if (!isAuthenticated) {
    return (
      <div className="app-shell fade-in">
        <div className="auth-hero" style={{ minHeight: '40vh', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
          <span className="auth-hero-emoji">🥗</span>
          <h1>DietWise</h1>
          <p>Smart nutrition — personalised for your health conditions</p>
        </div>
        <div style={{ padding: 'var(--gap-xl) var(--gap-lg)', display: 'flex', flexDirection: 'column', gap: 'var(--gap-md)' }}>
          <Link to="/auth" className={`btn btn-primary btn-block ${isElder ? 'btn-lg' : ''}`}>
            🚀 Get Started
          </Link>
          <div className="card">
            <div className="section-title">✨ What DietWise Does</div>
            {[
              ['🧮', 'Calculates your personal calorie target (BMR + TDEE)'],
              ['🏥', 'Adapts meals for Diabetes, Hypertension, Heart & Kidney Disease, Arthritis'],
              ['🍽', 'Gives a full day meal plan — cook or order mode'],
              ['🏃', 'Suggests safe exercises for your conditions'],
              ['🗺', 'Finds nearby diet-compatible restaurants'],
              ['🔊', 'Reads your plan aloud — great for elderly users'],
            ].map(([emoji, text]) => (
              <div key={text} style={{ display: 'flex', gap: 'var(--gap-sm)', alignItems: 'flex-start', padding: '8px 0', borderBottom: '1px solid var(--border)', fontSize: 'var(--fs-sm)' }}>
                <span>{emoji}</span> <span>{text}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  // Authenticated dashboard
  return (
    <div className="app-shell fade-in">
      <Navbar />
      <div className="page-content">
        {/* Welcome banner */}
        <div style={{
          background: 'linear-gradient(135deg, var(--primary) 0%, var(--primary-light) 100%)',
          borderRadius: 'var(--radius-lg)',
          padding: 'var(--gap-lg)',
          color: 'white',
          marginBottom: 'var(--gap-lg)',
        }}>
          <div style={{ fontSize: 'var(--fs-xs)', opacity: 0.8, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.08em' }}>
            Welcome back
          </div>
          <div style={{ fontFamily: 'var(--font-heading)', fontSize: isElder ? 'var(--fs-xl)' : 'var(--fs-lg)', fontWeight: 700, marginTop: '4px' }}>
            Hello, {user?.name?.split(' ')[0]}! 👋
          </div>
          <div style={{ opacity: 0.85, fontSize: 'var(--fs-sm)', marginTop: '4px' }}>
            {user?.profileComplete ? "Your profile is complete. Let's view your plan!" : 'Complete your profile to get your personalised plan.'}
          </div>
        </div>

        {/* Quick actions */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--gap-md)' }}>
          {user?.profileComplete ? (
            <Link to="/plan" className={`btn btn-primary btn-block ${isElder ? 'btn-lg' : ''}`}>
              🥗 View My Diet Plan
            </Link>
          ) : (
            <Link to="/profile" className={`btn btn-primary btn-block ${isElder ? 'btn-lg' : ''}`}>
              📝 Complete My Profile
            </Link>
          )}

          <Link to="/profile" className="btn btn-outline btn-block">
            👤 Update Health Profile
          </Link>

          <Link to="/history" className="btn btn-ghost btn-block">
            📋 View Plan History
          </Link>
        </div>

        {/* Status cards */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--gap-md)', marginTop: 'var(--gap-lg)' }}>
          <div className="card card-sm text-center">
            <div style={{ fontSize: '2rem' }}>
              {user?.profileComplete ? '✅' : '⏳'}
            </div>
            <div style={{ fontSize: 'var(--fs-xs)', fontWeight: 700, color: 'var(--text-muted)', marginTop: '4px' }}>
              Profile
            </div>
            <div style={{ fontSize: 'var(--fs-sm)', fontWeight: 700, color: user?.profileComplete ? 'var(--success)' : 'var(--warning)' }}>
              {user?.profileComplete ? 'Complete' : 'Incomplete'}
            </div>
          </div>
          <div className="card card-sm text-center">
            <div style={{ fontSize: '2rem' }}>🩺</div>
            <div style={{ fontSize: 'var(--fs-xs)', fontWeight: 700, color: 'var(--text-muted)', marginTop: '4px' }}>
              UI Mode
            </div>
            <div style={{ fontSize: 'var(--fs-sm)', fontWeight: 700, color: 'var(--primary)' }}>
              {isElder ? 'Elder' : 'Standard'}
            </div>
          </div>
        </div>

        <div style={{ height: 'var(--gap-2xl)' }} />
      </div>
    </div>
  )
}

export default HomePage
