// src/components/steps/Step1Plan.jsx
// Step 1: Calorie summary + BMR/TDEE + cook/order toggle + voice output

import { useMemo } from 'react'
import { useUI } from '../../context/UIContext'
import VoiceOutput from '../ui/VoiceOutput'
import Disclaimer from '../ui/Disclaimer'

const GOAL_COLORS = { loss: '#e74c3c', maintain: '#375D92', gain: '#2ecc71' }
const GOAL_LABELS = { loss: 'Weight Loss', maintain: 'Maintain Weight', gain: 'Muscle Gain' }

// Build the text spoken by "Read My Plan" button
const buildSpeechText = (planData) => {
  if (!planData) return ''
  const { summary, nutrition } = planData
  return `Hello ${summary.greeting.replace('Hello ', '')}. 
    Your goal is ${summary.goal}. 
    Your daily calorie target is ${summary.targetCalories} kilocalories. 
    Your Basal Metabolic Rate is ${nutrition.bmr} kilocalories. 
    Your Total Daily Energy Expenditure is ${nutrition.tdee} kilocalories. 
    You need ${nutrition.protein} grams of protein, 
    ${nutrition.carbs} grams of carbohydrates, 
    and ${nutrition.fat} grams of fat per day. 
    Drink at least ${nutrition.water} litres of water daily. 
    ${planData.warnings.length > 0 ? 'Important notes: ' + planData.warnings.slice(0, 2).join('. ') : ''}
    Tap Next to see your meal plan.`
}

const CalorieRing = ({ target, tdee }) => {
  // Ring represents target as % of tdee (capped 0–100%)
  const pct = Math.min(1, target / (tdee || target))
  const circumference = 502
  const offset = circumference - pct * circumference

  return (
    <div className="calorie-ring-wrap">
      <div className="calorie-ring">
        <svg width="180" height="180" viewBox="0 0 180 180">
          <circle className="calorie-ring-bg" cx="90" cy="90" r="80" />
          <circle
            className="calorie-ring-fill"
            cx="90" cy="90" r="80"
            style={{ '--ring-offset': offset, strokeDashoffset: offset }}
          />
        </svg>
        <div className="calorie-ring-center">
          <div className="calorie-big">{target.toLocaleString()}</div>
          <div className="calorie-unit">kcal / day</div>
        </div>
      </div>
      <div style={{ marginTop: 'var(--gap-sm)', fontSize: 'var(--fs-sm)', color: 'var(--text-muted)' }}>
        Your daily calorie target
      </div>
    </div>
  )
}

const Step1Plan = ({ planData, cookMode, onCookModeChange }) => {
  const { isElder } = useUI()
  const { summary, nutrition, warnings, activeConstraints } = planData

  const speechText = useMemo(() => buildSpeechText(planData), [planData])

  const goalColor = GOAL_COLORS[planData?.profileSnapshot?.goal] || 'var(--primary)'

  return (
    <div className="fade-in">
      {/* Greeting */}
      <div style={{ marginBottom: 'var(--gap-lg)' }}>
        <div className="page-title">{summary.greeting}</div>
        <div className="page-subtitle">Here's your personalised nutrition plan</div>
        <div style={{
          display: 'inline-block',
          marginTop: 'var(--gap-sm)',
          padding: '6px 16px',
          borderRadius: 'var(--radius-full)',
          background: goalColor + '20',
          border: `2px solid ${goalColor}`,
          color: goalColor,
          fontWeight: 700,
          fontSize: 'var(--fs-sm)',
        }}>
          🎯 Goal: {summary.goal}
        </div>
      </div>

      {/* Calorie ring */}
      <div className="card mb-md">
        <CalorieRing target={summary.targetCalories} tdee={summary.tdee} />

        {/* BMR / TDEE breakdown */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--gap-sm)', marginTop: 'var(--gap-sm)' }}>
          <div className="macro-card">
            <div className="macro-value" style={{ fontSize: 'var(--fs-lg)' }}>{nutrition.bmr}</div>
            <div className="macro-label">BMR kcal</div>
          </div>
          <div className="macro-card">
            <div className="macro-value" style={{ fontSize: 'var(--fs-lg)' }}>{nutrition.tdee}</div>
            <div className="macro-label">TDEE kcal</div>
          </div>
        </div>

        {/* Voice read button */}
        <div style={{ marginTop: 'var(--gap-md)' }}>
          <VoiceOutput text={speechText} label="🔊 Read My Plan Aloud" />
        </div>
      </div>

      {/* Macro targets */}
      <div className="card mb-md">
        <div className="section-title">📊 Daily Macro Targets</div>
        <div className="macro-grid">
          <div className="macro-card">
            <div className="macro-value" style={{ color: '#e74c3c' }}>{nutrition.protein}g</div>
            <div className="macro-label">Protein</div>
          </div>
          <div className="macro-card">
            <div className="macro-value" style={{ color: '#f39c12' }}>{nutrition.carbs}g</div>
            <div className="macro-label">Carbs</div>
          </div>
          <div className="macro-card">
            <div className="macro-value" style={{ color: '#2ecc71' }}>{nutrition.fat}g</div>
            <div className="macro-label">Fat</div>
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--gap-sm)', marginTop: 'var(--gap-md)' }}>
          <div className="macro-card">
            <div className="macro-value" style={{ color: '#3498db', fontSize: 'var(--fs-lg)' }}>
              {nutrition.water}L
            </div>
            <div className="macro-label">Water / Day</div>
          </div>
          <div className="macro-card">
            <div className="macro-value" style={{ color: '#9b59b6', fontSize: 'var(--fs-lg)' }}>
              {nutrition.sodium}mg
            </div>
            <div className="macro-label">Max Sodium</div>
          </div>
        </div>
      </div>

      {/* Cook / Order toggle */}
      <div className="card mb-md">
        <div className="section-title">🍳 Cooking Preference</div>
        <div className="cook-toggle">
          <div
            className={`cook-option ${cookMode === 'cook' ? 'active' : ''}`}
            onClick={() => onCookModeChange('cook')}
          >
            <div className="cook-icon">🍳</div>
            <div>Cook at Home</div>
          </div>
          <div
            className={`cook-option ${cookMode === 'order' ? 'active' : ''}`}
            onClick={() => onCookModeChange('order')}
          >
            <div className="cook-icon">🛵</div>
            <div>Order Food</div>
          </div>
        </div>
      </div>

      {/* Active disease constraints */}
      {activeConstraints.length > 0 && (
        <div className="card mb-md">
          <div className="section-title">🏥 Active Health Constraints</div>
          <div className="chip-group">
            {activeConstraints.map((c) => (
              <div key={c} className="chip active" style={{ cursor: 'default' }}>
                {c.replace('_', ' ')}
              </div>
            ))}
          </div>
          {warnings.length > 0 && (
            <div style={{ marginTop: 'var(--gap-md)', display: 'flex', flexDirection: 'column', gap: 'var(--gap-sm)' }}>
              {warnings.map((w, i) => (
                <div key={i} className="alert alert-info">
                  <span>ℹ️</span> <span>{w}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      <Disclaimer />
      <div style={{ height: 'var(--gap-xl)' }} />
    </div>
  )
}

export default Step1Plan
