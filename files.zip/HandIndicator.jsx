// src/components/layout/HandIndicator.jsx
// Animated 👉 shown near the Next button to guide elderly users

import { useUI } from '../../context/UIContext'

const HandIndicator = () => {
  const { isElder } = useUI()

  // Only show in elder mode (standard mode hides it)
  if (!isElder) return null

  return <span className="hand-indicator">👉</span>
}

export default HandIndicator
