// src/hooks/useVoiceInput.js
// Web Speech API — voice-to-text for form fields

import { useState, useRef, useCallback } from 'react'

const useVoiceInput = (onResult) => {
  const [listening, setListening] = useState(false)
  const [error, setError] = useState(null)
  const [supported] = useState(() => {
    return !!(window.SpeechRecognition || window.webkitSpeechRecognition)
  })
  const recognitionRef = useRef(null)

  const startListening = useCallback(() => {
    if (!supported) {
      setError('Voice input is not supported in this browser. Please use Chrome.')
      return
    }

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
    const recognition = new SpeechRecognition()

    recognition.continuous = false
    recognition.interimResults = false
    recognition.lang = 'en-IN' // Indian English as default (elderly Indian users)
    recognition.maxAlternatives = 1

    recognition.onstart = () => {
      setListening(true)
      setError(null)
    }

    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript
      if (onResult) onResult(transcript)
    }

    recognition.onerror = (event) => {
      setListening(false)
      if (event.error === 'no-speech') {
        setError('No speech detected. Please try again.')
      } else if (event.error === 'not-allowed') {
        setError('Microphone access denied. Please allow microphone access.')
      } else {
        setError(`Voice error: ${event.error}`)
      }
    }

    recognition.onend = () => {
      setListening(false)
    }

    recognitionRef.current = recognition
    recognition.start()
  }, [supported, onResult])

  const stopListening = useCallback(() => {
    if (recognitionRef.current) {
      recognitionRef.current.stop()
    }
    setListening(false)
  }, [])

  const toggleListening = useCallback(() => {
    if (listening) {
      stopListening()
    } else {
      startListening()
    }
  }, [listening, startListening, stopListening])

  return { listening, error, supported, startListening, stopListening, toggleListening }
}

export default useVoiceInput
