// src/App.jsx
// Root application — context providers + React Router routes

import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider } from './context/AuthContext'
import { UIProvider } from './context/UIContext'

// Pages & components
import HomePage        from './pages/HomePage'
import HistoryPage     from './pages/HistoryPage'
import AuthPage        from './components/auth/AuthPage'
import ProtectedRoute  from './components/auth/ProtectedRoute'
import ProfileForm     from './components/profile/ProfileForm'
import StepWrapper     from './components/steps/StepWrapper'
import Navbar          from './components/layout/Navbar'

// ── Plan page: Navbar + StepWrapper together ─────────────────────────────────
const PlanPage = () => (
  <div className="app-shell">
    <Navbar />
    <StepWrapper />
  </div>
)

// ── Profile page wrapper ───────────────────────────────────────────────────────
const ProfilePage = () => (
  <div className="app-shell">
    <Navbar />
    <ProfileForm />
  </div>
)

const App = () => (
  <BrowserRouter>
    <AuthProvider>
      <UIProvider>
        <Routes>
          {/* Public */}
          <Route path="/"     element={<HomePage />} />
          <Route path="/auth" element={<AuthPage />} />

          {/* Protected */}
          <Route
            path="/profile"
            element={
              <ProtectedRoute>
                <ProfilePage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/plan"
            element={
              <ProtectedRoute>
                <PlanPage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/history"
            element={
              <ProtectedRoute>
                <HistoryPage />
              </ProtectedRoute>
            }
          />

          {/* Catch-all */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </UIProvider>
    </AuthProvider>
  </BrowserRouter>
)

export default App
