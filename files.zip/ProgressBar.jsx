// src/components/layout/ProgressBar.jsx

import { useUI } from '../../context/UIContext'

const STEP_LABELS = ['Plan', 'Meals', 'Exercise', 'Nearby Food']

const ProgressBar = ({ currentStep, totalSteps = 4 }) => {
  const { isElder } = useUI()
  const pct = ((currentStep) / totalSteps) * 100

  return (
    <div style={{ padding: '12px var(--gap-lg) 0' }}>
      {/* Step label */}
      <div className="flex-between mb-sm">
        <span style={{ fontSize: 'var(--fs-xs)', fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.08em' }}>
          Step {currentStep} of {totalSteps}
        </span>
        <span style={{ fontSize: 'var(--fs-xs)', fontWeight: 700, color: 'var(--primary)' }}>
          {STEP_LABELS[currentStep - 1]}
        </span>
      </div>

      {/* Progress bar */}
      <div className="progress-track">
        <div className="progress-fill" style={{ width: `${pct}%` }} />
      </div>

      {/* Step dots */}
      <div className="step-dots mt-sm">
        {STEP_LABELS.map((label, i) => (
          <div
            key={i}
            className={`step-dot ${i + 1 === currentStep ? 'active' : ''} ${i + 1 < currentStep ? 'done' : ''}`}
            title={label}
          />
        ))}
      </div>

      {/* Elder: also show step name in large text */}
      {isElder && (
        <div style={{ textAlign: 'center', marginTop: 'var(--gap-sm)', fontWeight: 700, color: 'var(--primary)', fontSize: 'var(--fs-md)' }}>
          {STEP_LABELS[currentStep - 1]}
        </div>
      )}
    </div>
  )
}

export default ProgressBar
