// src/components/steps/StepWrapper.jsx
// Master controller for the 4-step plan flow

import { useState, useEffect, useCallback } from 'react'
import api from '../../api/axios'
import { useUI } from '../../context/UIContext'
import ProgressBar from '../layout/ProgressBar'
import HandIndicator from '../layout/HandIndicator'
import Step1Plan from './Step1Plan'
import Step2Meals from './Step2Meals'
import Step3Exercise from './Step3Exercise'
import Step4Food from './Step4Food'

const TOTAL_STEPS = 4

// Direction used to pick slide animation class
const ANIMATIONS = {
  forward: 'slide-in-right',
  backward: 'slide-in-left',
}

const StepWrapper = () => {
  const { isElder } = useUI()

  const [currentStep, setCurrentStep] = useState(1)
  const [direction, setDirection] = useState('forward')
  const [animKey, setAnimKey] = useState(0) // increment to re-trigger animation

  const [planData, setPlanData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [cookMode, setCookMode] = useState('cook')

  // Fetch the latest generated plan on mount
  const fetchPlan = useCallback(async (mode = cookMode) => {
    setLoading(true)
    setError(null)
    try {
      const { data } = await api.post('/diet/generate', { cookMode: mode })
      if (data.success) {
        setPlanData(data)
      } else {
        setError(data.message || 'Failed to generate plan')
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Could not load your plan. Please check your profile.')
    } finally {
      setLoading(false)
    }
  }, [cookMode])

  useEffect(() => {
    fetchPlan()
  }, []) // eslint-disable-line

  const handleCookModeChange = (mode) => {
    setCookMode(mode)
    fetchPlan(mode)
  }

  const navigate = (dir) => {
    setDirection(dir)
    setAnimKey((k) => k + 1)
    setCurrentStep((s) => (dir === 'forward' ? Math.min(s + 1, TOTAL_STEPS) : Math.max(s - 1, 1)))
  }

  const goNext = () => navigate('forward')
  const goBack = () => navigate('backward')

  // ── Loading state ─────────────────────────────────────────────────────────
  if (loading) {
    return (
      <div className="app-shell">
        <div className="spinner-wrap" style={{ paddingTop: '20vh' }}>
          <div className="spinner" />
          <div style={{ fontWeight: 700, color: 'var(--primary)', fontSize: 'var(--fs-md)' }}>
            Building your personalised plan...
          </div>
          <div style={{ fontSize: 'var(--fs-sm)', color: 'var(--text-muted)', textAlign: 'center', maxWidth: '260px' }}>
            Analysing your health profile and applying diet constraints
          </div>
        </div>
      </div>
    )
  }

  // ── Error state ────────────────────────────────────────────────────────────
  if (error) {
    return (
      <div className="app-shell">
        <div className="page-content" style={{ paddingTop: 'var(--gap-2xl)' }}>
          <div className="alert alert-danger mb-lg">
            <span>⚠️</span> {error}
          </div>
          <p style={{ fontSize: 'var(--fs-sm)', color: 'var(--text-secondary)', marginBottom: 'var(--gap-lg)' }}>
            Please make sure your profile has age, gender, height, and weight filled in.
          </p>
          <a href="/profile" className="btn btn-primary btn-block">
            📝 Complete Your Profile
          </a>
        </div>
      </div>
    )
  }

  // ── Render current step ────────────────────────────────────────────────────
  const stepProps = { planData, cookMode, onCookModeChange: handleCookModeChange, onRefresh: fetchPlan }

  const renderStep = () => {
    switch (currentStep) {
      case 1: return <Step1Plan {...stepProps} />
      case 2: return <Step2Meals {...stepProps} />
      case 3: return <Step3Exercise planData={planData} />
      case 4: return <Step4Food planData={planData} />
      default: return null
    }
  }

  return (
    <div className="app-shell">
      {/* Progress indicator — sticky below navbar */}
      <ProgressBar currentStep={currentStep} totalSteps={TOTAL_STEPS} />

      {/* Step content with slide animation */}
      <div
        key={animKey}
        className={`${ANIMATIONS[direction]} page-content`}
        style={{ paddingTop: 'var(--gap-md)' }}
      >
        {renderStep()}
      </div>

      {/* Step navigation footer */}
      <div className="step-nav">
        {/* Back button */}
        {currentStep > 1 ? (
          <button
            className="btn btn-outline"
            onClick={goBack}
            style={{ minWidth: isElder ? '100px' : '80px' }}
          >
            ← {isElder ? 'Back' : 'Back'}
          </button>
        ) : (
          <a
            href="/profile"
            className="btn btn-ghost"
            style={{ minWidth: '80px', textDecoration: 'none' }}
          >
            ✏️ Edit Profile
          </a>
        )}

        {/* Next button with hand indicator */}
        <div className="step-nav-next flex-center gap-sm">
          <HandIndicator />
          {currentStep < TOTAL_STEPS ? (
            <button
              className={`btn btn-primary ${isElder ? 'btn-lg' : ''}`}
              onClick={goNext}
              style={{ flex: 1 }}
            >
              Next →
            </button>
          ) : (
            <button
              className={`btn btn-danger ${isElder ? 'btn-lg' : ''}`}
              onClick={() => fetchPlan(cookMode)}
              style={{ flex: 1 }}
            >
              🔄 Regenerate Plan
            </button>
          )}
        </div>
      </div>
    </div>
  )
}

export default StepWrapper
