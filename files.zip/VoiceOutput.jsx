// src/components/ui/VoiceOutput.jsx
// "Read My Plan" button — uses Web Speech API SpeechSynthesis

import { useState, useCallback } from 'react'

const VoiceOutput = ({ text, label = '🔊 Read My Plan' }) => {
  const [speaking, setSpeaking] = useState(false)
  const supported = 'speechSynthesis' in window

  const speak = useCallback(() => {
    if (!supported || !text) return

    // Cancel any ongoing speech
    window.speechSynthesis.cancel()

    const utterance = new SpeechSynthesisUtterance(text)
    utterance.lang = 'en-IN'
    utterance.rate = 0.85   // Slightly slower for elderly users
    utterance.pitch = 1.0
    utterance.volume = 1.0

    // Pick a clear voice if available
    const voices = window.speechSynthesis.getVoices()
    const preferred = voices.find(
      (v) => v.lang.startsWith('en') && v.name.toLowerCase().includes('google')
    )
    if (preferred) utterance.voice = preferred

    utterance.onstart = () => setSpeaking(true)
    utterance.onend = () => setSpeaking(false)
    utterance.onerror = () => setSpeaking(false)

    window.speechSynthesis.speak(utterance)
  }, [supported, text])

  const stop = useCallback(() => {
    window.speechSynthesis.cancel()
    setSpeaking(false)
  }, [])

  if (!supported) return null

  return (
    <button
      className="voice-btn"
      onClick={speaking ? stop : speak}
      style={{ marginTop: 'var(--gap-sm)' }}
    >
      {speaking ? (
        <>
          <span style={{ fontSize: '1.1rem' }}>⏹</span> Stop Reading
        </>
      ) : (
        <>
          <span style={{ fontSize: '1.1rem' }}>🔊</span> {label}
        </>
      )}
    </button>
  )
}

export default VoiceOutput
