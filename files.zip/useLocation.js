// src/hooks/useLocation.js
// GPS geolocation with manual city-name fallback

import { useState, useCallback } from 'react'

const useLocation = () => {
  const [coords, setCoords] = useState(null)   // { lat, lon }
  const [city, setCity] = useState('')
  const [locationError, setLocationError] = useState(null)
  const [locating, setLocating] = useState(false)

  // ── GPS-based location ────────────────────────────────────────────────────────
  const getGPSLocation = useCallback(() => {
    if (!navigator.geolocation) {
      setLocationError('Geolocation is not supported by your browser.')
      return
    }
    setLocating(true)
    setLocationError(null)
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setCoords({ lat: position.coords.latitude, lon: position.coords.longitude })
        setLocating(false)
      },
      (err) => {
        setLocating(false)
        if (err.code === 1) setLocationError('Location access denied. Please enter your city manually.')
        else setLocationError('Could not get location. Please enter your city manually.')
      },
      { timeout: 10000, maximumAge: 300000 }
    )
  }, [])

  // ── Geocode a city name → lat/lon using Nominatim (OpenStreetMap) ─────────────
  const geocodeCity = useCallback(async (cityName) => {
    if (!cityName.trim()) return
    setLocating(true)
    setLocationError(null)
    try {
      const url = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(cityName)}&format=json&limit=1`
      const res = await fetch(url, { headers: { 'Accept-Language': 'en' } })
      const data = await res.json()
      if (data.length > 0) {
        setCoords({ lat: parseFloat(data[0].lat), lon: parseFloat(data[0].lon) })
        setCity(cityName)
      } else {
        setLocationError('City not found. Please try a different name.')
      }
    } catch {
      setLocationError('Failed to search location. Please check your internet connection.')
    } finally {
      setLocating(false)
    }
  }, [])

  return { coords, city, setCity, locationError, locating, getGPSLocation, geocodeCity }
}

export default useLocation
