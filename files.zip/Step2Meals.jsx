// src/components/steps/Step2Meals.jsx
// Step 2: Full meal plan — cook mode shows recipes, order mode shows restaurant suggestions

import { useUI } from '../../context/UIContext'
import Disclaimer from '../ui/Disclaimer'

const MEAL_SECTIONS = [
  { key: 'breakfast',    label: 'Breakfast',       emoji: '🌅', color: '#fff3cd' },
  { key: 'morningSnack', label: 'Morning Snack',   emoji: '🍎', color: '#d4edda' },
  { key: 'lunch',        label: 'Lunch',            emoji: '☀️', color: '#cce5ff' },
  { key: 'eveningSnack', label: 'Evening Snack',   emoji: '🍵', color: '#fde2e4' },
  { key: 'dinner',       label: 'Dinner',           emoji: '🌙', color: '#e2d9f3' },
]

// Single meal item card
const MealItem = ({ item }) => (
  <div className="meal-card fade-in">
    <div className="meal-card-header">
      <div className="meal-name">{item.name}</div>
      <div className="meal-cal">{item.calories} kcal</div>
    </div>
    <div className="meal-desc">{item.description}</div>

    {/* Macro pills */}
    <div style={{ display: 'flex', gap: '6px', marginTop: '8px', flexWrap: 'wrap' }}>
      <span style={{ fontSize: 'var(--fs-xs)', padding: '2px 8px', borderRadius: 'var(--radius-full)', background: '#fdecea', color: '#c0392b', fontWeight: 600 }}>
        P: {item.protein}g
      </span>
      <span style={{ fontSize: 'var(--fs-xs)', padding: '2px 8px', borderRadius: 'var(--radius-full)', background: '#fff8e6', color: '#9a6700', fontWeight: 600 }}>
        C: {item.carbs}g
      </span>
      <span style={{ fontSize: 'var(--fs-xs)', padding: '2px 8px', borderRadius: 'var(--radius-full)', background: '#e8f8ef', color: '#1a6638', fontWeight: 600 }}>
        F: {item.fat}g
      </span>
    </div>

    {/* Diet tags */}
    {item.tags && item.tags.length > 0 && (
      <div className="meal-tags">
        {item.tags.slice(0, 4).map((tag) => (
          <span key={tag} className="meal-tag">{tag.replace(/-/g, ' ')}</span>
        ))}
      </div>
    )}
  </div>
)

// Order suggestion card (when cookMode = 'order')
const OrderSuggestion = ({ suggestion }) => (
  <div className="card card-sm mb-md fade-in" style={{ borderLeft: '4px solid var(--primary)' }}>
    <div style={{ fontWeight: 700, fontSize: 'var(--fs-base)', marginBottom: 'var(--gap-sm)' }}>
      {suggestion.meal === 'Breakfast' ? '🌅' : suggestion.meal === 'Lunch' ? '☀️' : '🌙'} {suggestion.meal}
    </div>
    <ul style={{ paddingLeft: 'var(--gap-md)', color: 'var(--text-secondary)', fontSize: 'var(--fs-sm)', lineHeight: 2 }}>
      {suggestion.orderItems.map((item, i) => (
        <li key={i}>{item}</li>
      ))}
    </ul>
    {suggestion.tips && (
      <div className="alert alert-info mt-sm">
        <span>💡</span> <span style={{ fontSize: 'var(--fs-xs)' }}>{suggestion.tips}</span>
      </div>
    )}
  </div>
)

// Total calorie calculator for displayed meals
const calcTotalMealCals = (meals) => {
  let total = 0
  if (!meals) return 0
  Object.values(meals).forEach((section) => {
    section.forEach((item) => { total += item.calories || 0 })
  })
  return total
}

const Step2Meals = ({ planData, cookMode }) => {
  const { isElder } = useUI()
  const { meals, orderSuggestions, nutrition } = planData

  const displayedTotal = calcTotalMealCals(meals)

  if (cookMode === 'order' && orderSuggestions) {
    return (
      <div className="fade-in">
        <div className="page-title">🛵 Order Mode</div>
        <div className="page-subtitle mb-lg">
          Safe food choices to order from restaurants based on your health needs
        </div>

        <div className="alert alert-warning mb-md">
          <span>⚠️</span>
          <span>Always inform the restaurant about your dietary restrictions. Ask for minimal salt and oil.</span>
        </div>

        {orderSuggestions.map((s, i) => (
          <OrderSuggestion key={i} suggestion={s} />
        ))}

        <Disclaimer />
        <div style={{ height: 'var(--gap-xl)' }} />
      </div>
    )
  }

  return (
    <div className="fade-in">
      <div className="page-title">🍽 Your Meal Plan</div>
      <div className="page-subtitle">
        Personalised meals matched to your health conditions and preferences
      </div>

      {/* Total calories indicator */}
      <div className="card mb-md mt-md" style={{ textAlign: 'center', padding: 'var(--gap-md)' }}>
        <div style={{ fontSize: 'var(--fs-xs)', color: 'var(--text-muted)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em' }}>
          Today's Menu Total
        </div>
        <div style={{ fontSize: 'var(--fs-2xl)', fontWeight: 900, color: 'var(--primary)', fontFamily: 'var(--font-heading)' }}>
          {displayedTotal} <span style={{ fontSize: 'var(--fs-sm)', fontWeight: 600 }}>kcal</span>
        </div>
        <div style={{ fontSize: 'var(--fs-xs)', color: 'var(--text-muted)' }}>
          Target: {nutrition.targetCalories} kcal
        </div>
      </div>

      {/* Meal sections */}
      {MEAL_SECTIONS.map(({ key, label, emoji, color }) => {
        const items = meals[key]
        if (!items || items.length === 0) return null

        const sectionCals = items.reduce((sum, item) => sum + (item.calories || 0), 0)

        return (
          <div key={key} className="mb-md">
            <div
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                padding: '10px var(--gap-md)',
                background: color,
                borderRadius: 'var(--radius-md) var(--radius-md) 0 0',
                borderBottom: '1px solid var(--border)',
              }}
            >
              <div style={{ fontFamily: 'var(--font-heading)', fontWeight: 700, fontSize: isElder ? 'var(--fs-lg)' : 'var(--fs-md)' }}>
                {emoji} {label}
              </div>
              <div style={{ fontSize: 'var(--fs-sm)', fontWeight: 700, color: 'var(--primary)' }}>
                {sectionCals} kcal
              </div>
            </div>
            <div style={{ background: 'var(--card-bg)', borderRadius: '0 0 var(--radius-md) var(--radius-md)', padding: 'var(--gap-sm)', boxShadow: 'var(--shadow-sm)' }}>
              {items.map((item, i) => (
                <MealItem key={i} item={item} />
              ))}
            </div>
          </div>
        )
      })}

      <Disclaimer />
      <div style={{ height: 'var(--gap-xl)' }} />
    </div>
  )
}

export default Step2Meals
