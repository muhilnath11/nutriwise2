// src/pages/HistoryPage.jsx
// Shows a list of all previously generated diet plans

import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import api from '../api/axios'
import { useUI } from '../context/UIContext'
import Navbar from '../components/layout/Navbar'

const GOAL_LABELS = { loss: '📉 Weight Loss', maintain: '⚖️ Maintain', gain: '📈 Muscle Gain' }

const HistoryPage = () => {
  const { isElder } = useUI()
  const [plans, setPlans] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [page, setPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)

  const fetchHistory = async (p = 1) => {
    setLoading(true)
    try {
      const { data } = await api.get(`/history?page=${p}&limit=8`)
      setPlans(data.plans)
      setTotalPages(data.totalPages)
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to load history')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetchHistory(page) }, [page])

  const handleDelete = async (id) => {
    if (!confirm('Delete this plan?')) return
    try {
      await api.delete(`/history/${id}`)
      setPlans((prev) => prev.filter((p) => p._id !== id))
    } catch {
      alert('Failed to delete. Please try again.')
    }
  }

  return (
    <div className="app-shell">
      <Navbar />
      <div className="page-content">
        <div className="page-title mb-sm">📋 My Plan History</div>
        <div className="page-subtitle mb-lg">Your previously generated diet plans</div>

        {loading && (
          <div className="spinner-wrap">
            <div className="spinner" />
            <div style={{ color: 'var(--primary)', fontWeight: 700 }}>Loading history...</div>
          </div>
        )}

        {error && <div className="alert alert-danger">{error}</div>}

        {!loading && plans.length === 0 && (
          <div className="card text-center" style={{ padding: 'var(--gap-2xl)' }}>
            <div style={{ fontSize: '3rem', marginBottom: 'var(--gap-md)' }}>📭</div>
            <div style={{ fontWeight: 700, marginBottom: 'var(--gap-sm)' }}>No plans yet</div>
            <Link to="/plan" className="btn btn-primary">
              Generate Your First Plan →
            </Link>
          </div>
        )}

        {plans.map((plan) => (
          <div key={plan._id} className="card mb-md" style={{ position: 'relative' }}>
            <div className="flex-between mb-sm">
              <div style={{ fontWeight: 700, fontSize: isElder ? 'var(--fs-md)' : 'var(--fs-base)' }}>
                {new Date(plan.generatedDate).toLocaleDateString('en-IN', {
                  weekday: 'short', year: 'numeric', month: 'short', day: 'numeric',
                })}
              </div>
              <button
                onClick={() => handleDelete(plan._id)}
                style={{ color: 'var(--danger)', fontSize: 'var(--fs-xs)', fontWeight: 700, background: 'none', border: 'none', cursor: 'pointer' }}
              >
                🗑 Delete
              </button>
            </div>

            <div style={{ display: 'flex', gap: 'var(--gap-sm)', flexWrap: 'wrap' }}>
              <span className="chip active" style={{ cursor: 'default', fontSize: 'var(--fs-xs)' }}>
                🎯 {GOAL_LABELS[plan.profileSnapshot?.goal] || 'Plan'}
              </span>
              <span className="chip" style={{ cursor: 'default', fontSize: 'var(--fs-xs)' }}>
                🔥 {plan.nutrition?.targetCalories} kcal
              </span>
              <span className="chip" style={{ cursor: 'default', fontSize: 'var(--fs-xs)', background: plan.cookMode === 'cook' ? '#fff3cd' : '#cce5ff', borderColor: 'transparent' }}>
                {plan.cookMode === 'cook' ? '🍳 Cook' : '🛵 Order'}
              </span>
            </div>

            {plan.activeConstraints?.length > 0 && (
              <div className="chip-group mt-sm">
                {plan.activeConstraints.map((c) => (
                  <span key={c} style={{ fontSize: 'var(--fs-xs)', padding: '2px 8px', borderRadius: 'var(--radius-full)', background: 'var(--secondary)', color: 'var(--primary-dark)', fontWeight: 600 }}>
                    {c.replace('_', ' ')}
                  </span>
                ))}
              </div>
            )}
          </div>
        ))}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex-center gap-md mt-md">
            <button
              className="btn btn-outline"
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
            >
              ← Prev
            </button>
            <span style={{ fontWeight: 700, color: 'var(--text-secondary)' }}>
              Page {page} of {totalPages}
            </span>
            <button
              className="btn btn-outline"
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page === totalPages}
            >
              Next →
            </button>
          </div>
        )}

        <div style={{ height: 'var(--gap-2xl)' }} />
      </div>
    </div>
  )
}

export default HistoryPage
