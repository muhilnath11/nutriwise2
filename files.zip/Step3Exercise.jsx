// src/components/steps/Step3Exercise.jsx
// Step 3: Exercise recommendations from /api/exercise

import { useState, useEffect } from 'react'
import api from '../../api/axios'
import { useUI } from '../../context/UIContext'
import Disclaimer from '../ui/Disclaimer'

const INTENSITY_COLORS = {
  low:      { bg: '#d4edda', color: '#155724' },
  moderate: { bg: '#fff3cd', color: '#856404' },
  high:     { bg: '#fdecea', color: '#721c24' },
}

const EXERCISE_EMOJIS = {
  'Brisk Walking':                 '🚶',
  'Chair Yoga':                    '🧘',
  'Swimming / Water Aerobics':     '🏊',
  'Cycling (stationary or outdoor)': '🚴',
  'Resistance Band Exercises':     '💪',
  'Deep Breathing & Pranayama':    '🫁',
  'Light Stretching Routine':      '🤸',
  'Tai Chi':                       '🌀',
  'Post-meal 10-minute Walk':      '🍽️',
  'Upper Body Seated Exercises':   '🙆',
}

const ExerciseCard = ({ exercise, index }) => {
  const { isElder } = useUI()
  const intensityStyle = INTENSITY_COLORS[exercise.intensity] || INTENSITY_COLORS.low
  const emoji = EXERCISE_EMOJIS[exercise.name] || '🏃'

  return (
    <div
      className="exercise-card fade-in"
      style={{ animationDelay: `${index * 0.08}s` }}
    >
      <div className="exercise-icon">{emoji}</div>
      <div style={{ flex: 1 }}>
        <div style={{ fontWeight: 700, fontSize: isElder ? 'var(--fs-md)' : 'var(--fs-base)', color: 'var(--text-primary)' }}>
          {exercise.name}
        </div>
        <div style={{ fontSize: 'var(--fs-sm)', color: 'var(--text-secondary)', marginTop: '4px', lineHeight: 1.5 }}>
          {exercise.description}
        </div>
        <div style={{ display: 'flex', gap: '8px', marginTop: '8px', flexWrap: 'wrap' }}>
          {/* Duration */}
          <span style={{
            fontSize: 'var(--fs-xs)', padding: '3px 10px',
            borderRadius: 'var(--radius-full)',
            background: 'var(--secondary)', color: 'var(--primary-dark)', fontWeight: 700,
          }}>
            ⏱ {exercise.duration} min
          </span>
          {/* Intensity */}
          <span style={{
            fontSize: 'var(--fs-xs)', padding: '3px 10px',
            borderRadius: 'var(--radius-full)',
            background: intensityStyle.bg, color: intensityStyle.color, fontWeight: 700,
          }}>
            {exercise.intensity === 'low' ? '🟢' : exercise.intensity === 'moderate' ? '🟡' : '🔴'} {exercise.intensity}
          </span>
          {/* Calories */}
          {exercise.caloriesBurned && (
            <span style={{
              fontSize: 'var(--fs-xs)', padding: '3px 10px',
              borderRadius: 'var(--radius-full)',
              background: '#fdecea', color: '#c0392b', fontWeight: 700,
            }}>
              🔥 ~{exercise.caloriesBurned} kcal
            </span>
          )}
        </div>
      </div>
    </div>
  )
}

const Step3Exercise = () => {
  const { isElder } = useUI()
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    const fetchExercises = async () => {
      try {
        const { data: res } = await api.get('/exercise')
        setData(res)
      } catch (err) {
        setError(err.response?.data?.message || 'Failed to load exercises')
      } finally {
        setLoading(false)
      }
    }
    fetchExercises()
  }, [])

  if (loading) {
    return (
      <div className="spinner-wrap">
        <div className="spinner" />
        <div style={{ color: 'var(--primary)', fontWeight: 700 }}>Loading exercises...</div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="fade-in">
        <div className="alert alert-danger">{error}</div>
      </div>
    )
  }

  const { exercises, totalDuration, totalCaloriesBurned, advice } = data

  return (
    <div className="fade-in">
      <div className="page-title">🏃 Exercise Plan</div>
      <div className="page-subtitle">
        Safe, personalised exercises based on your health conditions
      </div>

      {/* Summary stats */}
      <div className="card mb-md mt-md">
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--gap-md)' }}>
          <div className="macro-card">
            <div className="macro-value">{totalDuration}</div>
            <div className="macro-label">Total Minutes</div>
          </div>
          <div className="macro-card">
            <div className="macro-value" style={{ color: '#e74c3c' }}>~{totalCaloriesBurned}</div>
            <div className="macro-label">kcal Burned</div>
          </div>
        </div>
      </div>

      {/* Exercise cards */}
      <div className="section-title">📋 Recommended Exercises</div>
      {exercises.length > 0 ? (
        exercises.map((ex, i) => <ExerciseCard key={i} exercise={ex} index={i} />)
      ) : (
        <div className="alert alert-info">
          No specific exercises found. Please complete your profile with your age and conditions.
        </div>
      )}

      {/* Safety advice */}
      {advice.length > 0 && (
        <div className="card mb-md mt-md">
          <div className="section-title">⚠️ Safety Guidelines</div>
          {advice.map((tip, i) => (
            <div key={i} className="alert alert-warning mb-sm" style={{ marginBottom: '8px' }}>
              <span>💡</span> <span style={{ fontSize: 'var(--fs-sm)' }}>{tip}</span>
            </div>
          ))}
        </div>
      )}

      {/* Weekly target */}
      <div className="alert alert-info mb-md">
        <span>🎯</span>
        <span>
          <strong>WHO Recommendation:</strong> Aim for 150 minutes of moderate activity per week.
          Your plan covers {totalDuration} minutes — repeat 5 days a week to meet this target.
        </span>
      </div>

      <Disclaimer />
      <div style={{ height: 'var(--gap-xl)' }} />
    </div>
  )
}

export default Step3Exercise
